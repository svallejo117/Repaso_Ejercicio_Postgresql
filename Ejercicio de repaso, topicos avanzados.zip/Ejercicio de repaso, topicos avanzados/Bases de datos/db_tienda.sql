-- Sistema de Ventas - Base de Datos PostgreSQL
-- Creación de tablas según el diagrama ER proporcionado

-- ======================================
-- Tabla Employee (Empleados)
-- ======================================
CREATE TABLE employee (
    employee_id SERIAL PRIMARY KEY,
    last_name VARCHAR(40) NOT NULL,
    first_name VARCHAR(20) NOT NULL,
    birth_date DATE,
    hire_date DATE,
    address VARCHAR(120),
    city VARCHAR(30),
    country VARCHAR(30),
    reports_to INTEGER REFERENCES employee(employee_id)
);

-- ======================================
-- Tabla Customer (Clientes)
-- ======================================
CREATE TABLE customer (
    customer_id SERIAL PRIMARY KEY,
    contact_name VARCHAR(30) NOT NULL,
    company_name VARCHAR(40),
    email VARCHAR(128),
    address VARCHAR(120),
    city VARCHAR(30),
    country VARCHAR(30)
);

-- ======================================
-- Tabla Supplier (Proveedores)
-- ======================================
CREATE TABLE supplier (
    supplier_id SERIAL PRIMARY KEY,
    nit VARCHAR(20) UNIQUE NOT NULL,
    name VARCHAR(100) NOT NULL,
    address VARCHAR(120)
);

-- ======================================
-- Tabla Category (Categorías)
-- ======================================
CREATE TABLE category (
    category_id SERIAL PRIMARY KEY,
    name VARCHAR(50) NOT NULL,
    description TEXT,
    parent_category_id INTEGER REFERENCES category(category_id)
);

-- ======================================
-- Tabla Product (Productos)
-- ======================================
CREATE TABLE product (
    product_id SERIAL PRIMARY KEY,
    product_name VARCHAR(40) NOT NULL,
    category_id INTEGER REFERENCES category(category_id),
    supplier_id INTEGER REFERENCES supplier(supplier_id),
    quantity_per_unit VARCHAR(50),
    unit_price DECIMAL(10,2),
    units_in_stock INTEGER,
    discontinued BOOLEAN DEFAULT FALSE
);

-- ======================================
-- Tabla Purchase (Compras)
-- ======================================
CREATE TABLE purchase (
    purchase_id SERIAL PRIMARY KEY,
    customer_id INTEGER REFERENCES customer(customer_id),
    employee_id INTEGER REFERENCES employee(employee_id),
    total_price DECIMAL(10,2),
    purchase_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    shipped_date TIMESTAMP,
    ship_address VARCHAR(60),
    ship_city VARCHAR(15),
    ship_country VARCHAR(15)
);

-- ======================================
-- Tabla Purchase_Item (Detalle de Compras)
-- ======================================
CREATE TABLE purchase_item (
    purchase_id INTEGER REFERENCES purchase(purchase_id),
    product_id INTEGER REFERENCES product(product_id),
    unit_price DECIMAL(10,2) NOT NULL,
    quantity INTEGER NOT NULL,
    PRIMARY KEY (purchase_id, product_id)
);

-- ======================================
-- INSERT DE EJEMPLO
-- ======================================

-- Empleados
INSERT INTO employee (last_name, first_name, birth_date, hire_date, address, city, country, reports_to)
VALUES 
    ('García', 'Ana', '1985-03-15', '2020-01-10', 'Calle 123 #45-67', 'Bogotá', 'Colombia', NULL),
    ('Rodríguez', 'Carlos', '1990-07-22', '2021-03-05', 'Carrera 45 #12-34', 'Medellín', 'Colombia', 1),
    ('Martínez', 'Laura', '1988-11-08', '2019-09-15', 'Avenida 80 #23-56', 'Cali', 'Colombia', 1);

-- Clientes
INSERT INTO customer (contact_name, company_name, email, address, city, country)
VALUES 
    ('Juan Pérez', 'Tecnología S.A.S.', 'juan.perez@tecnologia.com', 'Calle 50 #12-34', 'Bogotá', 'Colombia'),
    ('María González', 'Comercial Ltda.', 'maria.gonzalez@comercial.com', 'Carrera 70 #45-67', 'Medellín', 'Colombia'),
    ('Pedro López', 'Distribuidora XYZ', 'pedro.lopez@distribuidora.com', 'Avenida 6 #78-90', 'Cali', 'Colombia'),
    ('Carmen Silva', 'Empresas Unidas', 'carmen.silva@empresas.com', 'Calle 25 #56-78', 'Barranquilla', 'Colombia');

-- Proveedores
INSERT INTO supplier (nit, name, address)
VALUES 
    ('900123456-7', 'Tecnología Global S.A.S.', 'Zona Franca Bogotá'),
    ('800987654-3', 'Importadora TecnoMax', 'Carrera 15 #123-45, Medellín'),
    ('700456789-1', 'Distribuciones Electro', 'Calle 80 #67-89, Cali');

-- Categorías
INSERT INTO category (name, description, parent_category_id)
VALUES 
    ('Electrónicos', 'Productos electrónicos y tecnológicos', NULL),
    ('Computadoras', 'Equipos de cómputo y accesorios', 1),
    ('Smartphones', 'Teléfonos inteligentes y accesorios', 1),
    ('Hogar', 'Productos para el hogar', NULL),
    ('Cocina', 'Electrodomésticos de cocina', 4);

-- Productos (con relación a un proveedor)
INSERT INTO product (product_name, category_id, supplier_id, quantity_per_unit, unit_price, units_in_stock, discontinued)
VALUES 
    ('Laptop Dell Inspiron', 2, 1, '1 unidad', 2500000.00, 15, FALSE),
    ('iPhone 14 Pro', 3, 2, '1 unidad', 4200000.00, 8, FALSE),
    ('Mouse Inalámbrico', 2, 1, '1 unidad', 45000.00, 50, FALSE),
    ('Licuadora Premium', 5, 3, '1 unidad', 180000.00, 25, FALSE),
    ('Tablet Samsung', 1, 2, '1 unidad', 800000.00, 20, FALSE),
    ('Microondas LG', 5, 3, '1 unidad', 320000.00, 12, FALSE);

-- Compras
INSERT INTO purchase (customer_id, employee_id, total_price, purchase_date, ship_address, ship_city, ship_country)
VALUES 
    (1, 2, 2545000.00, '2024-08-01 10:30:00', 'Calle 50 #12-34', 'Bogotá', 'Colombia'),
    (2, 1, 4200000.00, '2024-08-05 14:20:00', 'Carrera 70 #45-67', 'Medellín', 'Colombia'),
    (3, 3, 980000.00, '2024-08-10 09:15:00', 'Avenida 6 #78-90', 'Cali', 'Colombia');

-- Detalles de compras
INSERT INTO purchase_item (purchase_id, product_id, unit_price, quantity)
VALUES 
    -- Compra 1: Laptop + Mouse
    (1, 1, 2500000.00, 1),
    (1, 3, 45000.00, 1),
    -- Compra 2: iPhone
    (2, 2, 4200000.00, 1),
    -- Compra 3: Tablet + Licuadora
    (3, 5, 800000.00, 1),
    (3, 4, 180000.00, 1);

--Ejercicio 8, me faltaron estos datos para que funcione bien la consulta
-- Agregamos productos descatalogados en la categoría 1 (Electrónicos)
INSERT INTO product (product_name, category_id, supplier_id, quantity_per_unit, unit_price, units_in_stock, discontinued)
VALUES
('Cámara Sony Alpha', 1, 1, '1 unidad', 3200000.00, 5, TRUE),
('Audífonos Bose', 1, 2, '1 unidad', 950000.00, 10, TRUE),
('Smartwatch Garmin', 1, 2, '1 unidad', 1200000.00, 8, TRUE);

-- Agregamos productos descatalogados en la categoría 2 (Computadoras)
INSERT INTO product (product_name, category_id, supplier_id, quantity_per_unit, unit_price, units_in_stock, discontinued)
VALUES
('Teclado Mecánico', 2, 1, '1 unidad', 250000.00, 20, TRUE),
('Monitor LG 24"', 2, 3, '1 unidad', 800000.00, 15, TRUE),
('Impresora HP', 2, 1, '1 unidad', 600000.00, 5, TRUE);

-- Agregamos productos descatalogados en la categoría 5 (Cocina)
INSERT INTO product (product_name, category_id, supplier_id, quantity_per_unit, unit_price, units_in_stock, discontinued)
VALUES
('Cafetera Eléctrica', 5, 3, '1 unidad', 300000.00, 12, TRUE),
('Tostadora Philips', 5, 3, '1 unidad', 180000.00, 10, TRUE),
('Batidora Oster', 5, 3, '1 unidad', 250000.00, 7, TRUE);