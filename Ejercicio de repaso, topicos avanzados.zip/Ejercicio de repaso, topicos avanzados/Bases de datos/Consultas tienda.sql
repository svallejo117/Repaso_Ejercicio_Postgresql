-- ======================================
-- CONSULTAS - Base de Datos Tienda
-- ======================================

-- 1. Mostrar los datos de todos los productos de las categorías con un ID de 1 (Alimentos)
--    o 5 (Frutas y Verduras) y con un precio unitario superior a 3.5
SELECT *
FROM product
WHERE category_id IN (1, 5) 
  AND unit_price > 3.5;

-- 2. Mostrar los nombres de los productos con un precio unitario mayor o igual a 3.5
SELECT product_name
FROM product
WHERE unit_price >= 3.5;

-- 3. Seleccionar nombres de productos junto con sus categorías
--    Mostrando columnas: product_name y category_name
SELECT p.product_name, c.name AS category_name
FROM product p
JOIN category c ON p.category_id = c.category_id;

-- 4. Para cada compra, mostrar ID de compra, nombre del producto, 
--    precio unitario en la compra y cantidad
SELECT pi.purchase_id, p.product_name, pi.unit_price, pi.quantity
FROM purchase_item pi
JOIN product p ON pi.product_id = p.product_id
ORDER BY pi.purchase_id;

-- 5. Para cada compra, mostrar todas las categorías de productos comprados 
--    (cada categoría solo una vez por compra)
SELECT DISTINCT pi.purchase_id, c.name AS category_name
FROM purchase_item pi
JOIN product p ON pi.product_id = p.product_id
JOIN category c ON p.category_id = c.category_id
ORDER BY pi.purchase_id, c.name;

-- 6. Mostrar apellidos, nombres, fecha de nacimiento y edad de empleados,
--    ordenados por la edad del empleado en orden ascendente (jóvenes primero)
SELECT 
    last_name, 
    first_name, 
    birth_date,
    EXTRACT(YEAR FROM AGE(CURRENT_DATE, birth_date)) AS edad
FROM employee
ORDER BY birth_date DESC;

-- 7. Contar cuántos clientes viven en cada ciudad, 
--    excepto en Knoxville y Stockton
--    Mostrar columnas: city y customers_quantity
SELECT city, COUNT(*) AS customers_quantity
FROM customer
WHERE city NOT IN ('Knoxville', 'Stockton')
GROUP BY city
ORDER BY city ASC;

-- 8. Para cada categoría, encontrar el número de productos descatalogados (discontinued = TRUE)
--    Mostrar solo las categorías con al menos 3 productos descatalogados
--    Ordenar por número de productos descatalogados en orden descendente
--    Mostrar columnas: name y discontinued_products_number
SELECT c.name, COUNT(*) AS discontinued_products_number
FROM product p
JOIN category c ON p.category_id = c.category_id
WHERE p.discontinued = TRUE
GROUP BY c.name
HAVING COUNT(*) >= 3
ORDER BY discontinued_products_number DESC;
