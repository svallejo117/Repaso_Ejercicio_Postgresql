
-- Tabla Docente
CREATE TABLE Docente (
    id_docente SERIAL PRIMARY KEY,
    nombres VARCHAR(100) NOT NULL,
    direccion VARCHAR(250),
    telefono VARCHAR(20)
);

-- Tabla Materia
CREATE TABLE Materia (
    id_materia SERIAL PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    id_docente INT,
    CONSTRAINT FK_Materia_id_docente
        FOREIGN KEY (id_docente) REFERENCES Docente(id_docente)
);

-- Tabla Estudiante
CREATE TABLE Estudiante (
    id_estudiante SERIAL PRIMARY KEY,
    codigo_universitario VARCHAR(20) UNIQUE NOT NULL,
    nombres VARCHAR(100) NOT NULL,
    apellidos VARCHAR(100) NOT NULL,
    fecha_nacimiento DATE
);

-- Tabla Matricula
CREATE TABLE Matricula (
    id_matricula SERIAL PRIMARY KEY,
    id_estudiante INT,
    id_materia INT,
    CONSTRAINT FK_Matricula_id_estudiante
        FOREIGN KEY (id_estudiante) REFERENCES Estudiante(id_estudiante),
    CONSTRAINT FK_Matricula_id_materia
        FOREIGN KEY (id_materia) REFERENCES Materia(id_materia)
);



-- Insertar datos de ejemplo

-- ========================
-- DOCENTES
-- ========================
INSERT INTO Docente (nombres, direccion, telefono) VALUES
('Carlos Pérez', 'Calle 10 # 23-45', '3156789012'),
('María Gómez', 'Cra 7 # 12-34', '3109876543'),
('Julián Martínez', 'Av. Siempre Viva 742', '3124567890'),
('Laura Rodríguez', 'Calle 50 # 20-15', '3112223344'),
('Andrés Ramírez', 'Cra 45 # 56-67', '3165556677');

-- ========================
-- MATERIAS
-- ========================
INSERT INTO Materia (nombre, id_docente) VALUES
('Bases de Datos', 1),
('Programación I', 2),
('Matemáticas Discretas', 1),
('Estructuras de Datos', 3),
('Sistemas Operativos', 4),
('Redes de Computadores', 5),
('Inteligencia Artificial', 3),
('Programación Web', 2);

-- ========================
-- ESTUDIANTES
-- ========================
INSERT INTO Estudiante (codigo_universitario, nombres, apellidos, fecha_nacimiento) VALUES
('U2025001', 'Sebastián', 'Vallejo', '2000-05-12'),
('U2025002', 'Camila', 'Rojas', '2001-03-08'),
('U2025003', 'Andrés', 'López', '1999-11-20'),
('U2025004', 'Valentina', 'Torres', '2002-07-25'),
('U2025005', 'Felipe', 'González', '2000-01-15'),
('U2025006', 'Natalia', 'Hernández', '1998-09-30'),
('U2025007', 'Juan', 'Cárdenas', '2001-11-02'),
('U2025008', 'Sofía', 'Pérez', '2002-04-10'),
('U2025009', 'Daniel', 'Castro', '1999-06-18'),
('U2025010', 'Isabella', 'Moreno', '2000-12-09');

-- ========================
-- MATRÍCULAS
-- ========================
INSERT INTO Matricula (id_estudiante, id_materia) VALUES
-- Sebastián
(1, 1), (1, 2), (1, 4),
-- Camila
(2, 1), (2, 2), (2, 5),
-- Andrés
(3, 3), (3, 6),
-- Valentina
(4, 1), (4, 7),
-- Felipe
(5, 2), (5, 4), (5, 8),
-- Natalia
(6, 5), (6, 6),
-- Juan
(7, 2), (7, 4), (7, 7),
-- Sofía
(8, 1), (8, 8),
-- Daniel
(9, 3), (9, 6), (9, 5),
-- Isabella
(10, 2), (10, 7), (10, 8);
